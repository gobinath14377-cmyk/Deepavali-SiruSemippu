தீபாவளி சிறுசேமிப்பு திட்டம் - Android V31

இந்த Android project-இல் V31 HTML இணைக்கப்பட்டுள்ளது.

முக்கியம்:
1. App ID (in.deepavali.sirussemippu) அதேபடி வைக்கப்பட்டுள்ளது.
2. Local data key (deepavali_siru_semippu_v1) அதேபடி வைக்கப்பட்டுள்ளது. அதனால் அதே app signature-இல் update செய்தால் பழைய உறுப்பினர் / லீடர் / வசூல் தரவு தொடர வேண்டும்.
3. APK-ஐ update செய்வதற்கு முன் app-இல் Backup எடுத்து Google Sheets-ல் சரிபார்க்கவும்.
4. பழைய app-ஐ uninstall செய்ய வேண்டாம். Uninstall செய்தால் உள்ளூர் data அழியலாம்.
5. ஏற்கனவே நிறுவிய app-ஐ update செய்ய, அதே signing key-இல் build செய்யப்பட்ட APK தேவை. Signature மாறினால் Android update-ஐ ஏற்காது; பழைய app-ஐ நீக்கி நிறுவ வேண்டிய நிலை வரலாம், அதனால் local data இழக்கலாம்.
6. versionCode 31, versionName 31.0.
