தீபாவளி சிறுசேமிப்பு – Android Studio Project

இந்த ZIP நேரடியாக நிறுவும் APK அல்ல. இது APK உருவாக்குவதற்கான Android Studio Project.

உள்ளடக்கம்:
- Android launcher icon
- PIN இல்லாமல் நேரடியாக திறக்கும் WebView app
- V8 HTML app assets-ல் சேர்க்கப்பட்டுள்ளது
- LocalStorage மூலம் சாதனத்தில் சேமிக்கும் வசதி

APK உருவாக்க:
1. Android Studio-வை கணினியில் திறக்கவும்.
2. இந்த ZIP-ஐ Extract செய்யவும்.
3. Android Studio > Open > DeepavaliSiruSemippu folder தேர்வு செய்யவும்.
4. Gradle Sync முடிந்ததும் Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK: app/build/outputs/apk/debug/app-debug.apk

GitHub Actions வழி:
1. Project-ஐ GitHub repository-க்கு upload/push செய்யவும்.
2. Actions tab-ல் Android APK Build workflow ஓடும்.
3. முடிந்ததும் workflow Artifacts பகுதியில் debug APK கிடைக்கும்.

கவனம்:
- முதல் முறை Google Sheets backup/restore செயல்பாட்டை உண்மையான சாதனத்தில் சோதிக்கவும்.
- இந்த APK-ல் PIN login இல்லை. மொபைலைப் பயன்படுத்தக்கூடியவர் app-ஐத் திறக்கலாம்.
- SMS/WhatsApp ரசீது அனுப்புவது சாதனத்தின் installed apps / user action சார்ந்தது; தானாக பின்னணியில் அனுப்பும் backend இதில் சேர்க்கப்படவில்லை.
